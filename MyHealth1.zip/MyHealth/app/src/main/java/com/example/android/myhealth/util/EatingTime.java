package com.example.android.myhealth.util;

public enum EatingTime {
    BEFORE,
    WHILE,
    AFTER
}
