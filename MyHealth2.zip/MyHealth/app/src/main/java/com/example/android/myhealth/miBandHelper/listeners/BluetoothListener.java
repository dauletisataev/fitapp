package com.example.android.myhealth.miBandHelper.listeners;

public interface BluetoothListener {

    void onResult(String heartRate);
}
